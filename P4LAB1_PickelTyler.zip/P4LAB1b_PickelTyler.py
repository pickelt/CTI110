# Tyler Pickel
# P4LAB1b - Initials with turtle
# Draw the initials "T" and "P" with simple turtle moves.
# Beginner style with clear steps and comments.

import turtle

t = turtle.Turtle()
t.speed(5)
t.pensize(5)
t.color("black")

# Helper: move without drawing
def jump(x, y):
    t.penup()
    t.goto(x, y)
    t.pendown()

# Draw letter T
# top bar
jump(-180, 100)
t.forward(120)            # horizontal top
# center stem
t.backward(60)            # go to middle of the top bar
t.right(90)
t.forward(160)            # stem down

# Draw letter P (block style)
jump(20, -60)             # start at bottom-left of the P stem
t.left(90)                # face right again
t.left(90)                # now face up
t.forward(160)            # vertical stem up

# top rectangle for P loop (simple boxy look)
t.right(90)
t.forward(80)             # top right
t.right(90)
t.forward(70)             # down half-height
t.right(90)
t.forward(80)             # back to stem
# leave the inner gap by not drawing the last side

# small finishing touch so it's clearly a P
t.right(180)
t.forward(40)             # small inner line

# done
t.hideturtle()
turtle.done()
