# Tyler Pickel
# P4LAB1a - Shapes with loops
# Draw a square and a triangle using turtle graphics and loops.
# NOTE: This is beginner-style code on purpose.

import turtle

# setup
t = turtle.Turtle()
t.speed(5)
t.pensize(3)

# --- draw a square using a for loop ---
t.color("blue")
side = 120
for _ in range(4):        # 4 equal sides
    t.forward(side)
    t.right(90)

# move a little so the triangle is visible if it overlaps
t.penup()
t.goto(-20, -20)
t.pendown()

# --- draw a triangle using a for loop ---
t.color("red")
for _ in range(3):        # 3 equal sides
    t.forward(side)
    t.left(120)

# keep window open until user clicks
turtle.done()
