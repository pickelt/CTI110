# Tyler Pickel
# P4LAB1a - Shapes with loops
# Draw a square and a triangle using turtle graphics and loops.

import turtle

t = turtle.Turtle()

# draw a square using a for loop
for side in range(4):
    t.forward(100)
    t.right(90)

# move the turtle a little using forward and turn instead of goto
t.penup()
t.forward(150)
t.pendown()

# draw a triangle using a for loop
for side in range(3):
    t.forward(100)
    t.left(120)

# keep window open until user clicks
turtle.done()
