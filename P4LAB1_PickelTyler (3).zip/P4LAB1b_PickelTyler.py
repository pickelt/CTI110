# Tyler Pickel
# P4LAB1b - Drawing my initials with turtle


import turtle

t = turtle.Turtle()

# draw first initial "T"
t.forward(80)
t.backward(40)
t.right(90)
t.forward(100)
t.left(90)

# move to the right for next letter
t.penup()
t.forward(100)
t.pendown()

# draw second initial "P"
t.left(90)
t.forward(100)
t.right(90)
t.forward(40)
t.right(90)
t.forward(50)
t.right(90)
t.forward(40)

# keep window open until user closes
turtle.done()
